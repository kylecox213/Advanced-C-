﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SimpleException
{
    [Serializable]
    public class VehicleDisabledException : ApplicationException
    {
        public VehicleDisabledException() { }
        public VehicleDisabledException(string message) : base(message) { }
        public VehicleDisabledException(string message, Exception inner) : base(message, inner) { }
        protected VehicleDisabledException(
          System.Runtime.Serialization.SerializationInfo info,
          System.Runtime.Serialization.StreamingContext context)
            : base(info, context) { }

        // Custom members for exception filters.
        public DateTime ErrorTimeStamp { get; set; }
        public string CauseOfError { get; set; }
        public VehicleDisabledException(string message, string cause, DateTime time)
            : base(message)
        {
            CauseOfError = cause;
            ErrorTimeStamp = time;
        }
    }
}
