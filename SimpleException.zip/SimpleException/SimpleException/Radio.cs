﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SimpleException
{
    class Radio
    {
        public void TurnOn(bool on)
        {
          Console.WriteLine(on ? "Kick out the jams..." : "Hello, silence my old friend....");
        }
    }
}
