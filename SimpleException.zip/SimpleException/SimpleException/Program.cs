﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using System.Collections;
using System.Threading;

namespace SimpleException
{


    //****Simple Exception*****


    // class Program
    // {
    //     static void Main(string[] args)
    //     {

    //         Console.WriteLine("=> Initiating vehicle acceleration");
    //         Car myCar = new Car("The Champagne Dream", 50);
    //         myCar.CrankTunes(true);
    //         myCar.CrankTunes(false);

    //try
    //{
    //	for (int i = 0; i < 10; i++)
    //                 myCar.Accelerate(10);
    //             Thread.Sleep(100);
    //   }
    //         catch (Exception e)
    //         {
    //             Console.WriteLine("\n*** An exception was thrown. ***");
    //             Console.WriteLine("Member name: {0}", e.TargetSite);
    //             Console.WriteLine("Class defining member: {0}",
    //               e.TargetSite.DeclaringType);
    //             Console.WriteLine("Member type: {0}", e.TargetSite.MemberType);
    //             Console.WriteLine("Message: {0}", e.Message);
    //             Console.WriteLine("Source: {0}", e.Source);
    //             Console.WriteLine("Stack: {0}", e.StackTrace);
    //             Console.WriteLine("Help Link: {0}", e.HelpLink);
    //             Console.WriteLine("\n-> Custom Data:");

    //             foreach (DictionaryEntry de in e.Data)
    //                 Console.WriteLine("-> {0}: {1}", de.Key, de.Value);
    //         }
    //      Console.ReadLine();

    //     }
    // }




    // ****** Custom Exception*****

    //class Program
    //{
    //    static void Main(string[] args)
    //    {
    //        Console.WriteLine("***** Fun with Custom Exceptions *****\n");
    //        Car myCar = new Car("Rusty", 90);

    //        try
    //        {
    //            // Trip exception.
    //            myCar.Accelerate(50);
    //        }
    //        catch (VehicleDisabledException e)
    //        {
    //            Console.WriteLine(e.Message);
    //            Console.WriteLine(e.ErrorTimeStamp);
    //            Console.WriteLine(e.CauseOfError);
    //        }
    //        Console.ReadLine();
    //    }
    //}

    //******Process Multiple Exceptions*******  

    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("***** Handling Multiple Exceptions *****\n");
            Car myCar = new Car("Big Blue", 90);

            #region Try/catch logic
            try
            {
                // Trip Arg out of range exception.
                myCar.Accelerate(1000);
            }
            // Add a when clause to the VehicleDiabledException handler,
            // ensuring that the catch block is never executed on a Friday.
            catch (VehicleDisabledException e) when (e.ErrorTimeStamp.DayOfWeek != DayOfWeek.Friday)
            {
                Console.WriteLine("Catching car is dead!");
                Console.WriteLine(e.Message);
            }
            catch (ArgumentOutOfRangeException e)
            {
                Console.WriteLine(e.Message);
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
            finally
            {
                // finally block will always turn off the radio before exiting the Main method
                myCar.CrankTunes(false);
            }
            #endregion

            Console.ReadLine();
        }
    }

}
