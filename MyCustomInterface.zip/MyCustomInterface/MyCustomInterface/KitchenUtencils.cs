﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyCustomInterface
{
    class Knife : Shape, IShapePoints, IDraw3D
    {
        public Knife() { }
        public Knife(string name) : base(name) { }

        public override void Draw()
        { Console.WriteLine("Drawing {0} the Knife", ShapeName); }

        public void Draw3D()
        {
            { Console.WriteLine("Drawing Knife in 3D"); }
        }

        // IShapePoints implementation
        public byte Points
        {
            get { return 1; }
        }
    }

    class Fork : Shape, IShapePoints, IDraw3D
    {
        public Fork() { }
        public Fork(string name) : base(name) { }

        public override void Draw()
        { Console.WriteLine("Drawing {0} the Fork", ShapeName); }

        public void Draw3D()
        {
            { Console.WriteLine("Drawing Fork in 3D"); }
        }

        // IShapePoints implementation
        public byte Points
        {
            get { return 3; }
        }
    }

    class Spoon : Shape, IShapePoints, IDraw3D
    {
        public Spoon() { }
        public Spoon(string name) : base(name) { }

        public override void Draw()
        { Console.WriteLine("Drawing {0} the Spoon", ShapeName); }

        public void Draw3D()
        {
            { Console.WriteLine("Drawing Spoon in 3D"); }
        }

        // IShapePoints implementation
        public byte Points
        {
            get { return 0; }
        }
    }
}