﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyCustomInterface
{
    class Pitchfork : Shape, IShapePoints, IDraw3D
    {
        public Pitchfork() { }
        public Pitchfork(string name) : base(name) { }

        public override void Draw()
        { Console.WriteLine("Drawing {0} the Pitchfork", ShapeName); }

        public void Draw3D()
        {
            { Console.WriteLine("Drawing Pitchfork in 3D"); }
        }

        // IShapePoints implementation
        public byte Points
        {
            get { return 3; }
        }
    }

    class Shovel : Shape, IShapePoints, IDraw3D
    {
        public Shovel() { }
        public Shovel(string name) : base(name) { }

        public override void Draw()
        { Console.WriteLine("Drawing {0} the Shovel", ShapeName); }

        public void Draw3D()
        {
            { Console.WriteLine("Drawing Shovel in 3D"); }
        }

        // IShapePoints implementation
        public byte Points
        {
            get { return 3; }
        }
    }
}
