﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyCustomInterface
{
    // The abstract base class of the hierarchy
    abstract class Shape
    {
        public Shape(string name = "John Doe")
        { ShapeName = name; }

        public string ShapeName { get; set; }

        // Force all child classes to define how to be rendered
        public abstract void Draw();
    }

    #region Circle 
    class Circle : Shape, IShapePoints
    {
        public Circle() { }
        public Circle(string name) : base(name) { }
        public override void Draw()
        {
            Console.WriteLine("Drawing {0} the Circle", ShapeName);
        }

        public byte Points
		{
            get => 0;
		}
    }
    #endregion

    #region Hexagon 

    // Updated hexagon type to support IShapePoints interface type
    class Hexagon : Shape, IShapePoints
    {
        public Hexagon() { }
        public Hexagon(string name) : base(name) { }
        public override void Draw()
        {
            Console.WriteLine("Drawing {0} the Hexagon", ShapeName);
        }

        // IShapePoints implementation
        public byte Points
        {
            get => 6;
        }

        public void Draw3D()
        { Console.WriteLine("Drawing Hexagon in 3D!"); }
    }
    #endregion

    #region 3D circle
    class ThreeDCircle : Circle, IDraw3D, IShapePoints
    {
        public new string ShapeName { get; set; }

        public new void Draw()
        {
            Console.WriteLine("Drawing a 3D Circle");
        }
        public void Draw3D()
        { Console.WriteLine("Drawing Another Circle in 3D!"); }

        public byte Points
		{
            get => 0; 
		}
    }
    #endregion

    #region Octagon

    // Implementation of name clashes with interface types; each calling on the same Draw() method
    class Octagon : IExplicitInterface.IDrawToForm, IExplicitInterface.IDrawToMemory, IExplicitInterface.IDrawToPrinter, IShapePoints
    {
        public void Draw()
        {
            Console.WriteLine("Drawing the Octagon shape...");
        }

        public byte Points
        {
            get => 8;
        }
    }
    #endregion

    #region Septagon

    // Utilize explicit interface implementation syntax to explicitly bind Draw() implementations to a specific interface type
    class Septagon : IExplicitInterface.IDrawToForm, IExplicitInterface.IDrawToMemory, IExplicitInterface.IDrawToPrinter, IShapePoints
    {
        public void Draw()
		{
            Console.WriteLine("Drawing the Septagon shape...");
		}

        public byte Points
        {
            get => 7;
        }
    }
    #endregion
}
