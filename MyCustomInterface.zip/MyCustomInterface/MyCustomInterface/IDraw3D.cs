﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyCustomInterface
{
	public interface IDraw3D
	{
		void Draw3D();
	}


	public interface IDrawShapesIn3D
	{
		void DrawShapesIn3D();
	}
}
