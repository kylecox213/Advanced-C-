﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyCustomInterface
{
    class Nonagon : IShapePoints, IDrawToApp
    {
        public void Draw()
        {
            Console.WriteLine("Drawing the Nonagon shape...");
        }

        void IDrawToApp.Draw()
		{
            Console.WriteLine("Drawing To App");
		}

        public byte Points
        {
            get { return 9; }
        }
    }
}
