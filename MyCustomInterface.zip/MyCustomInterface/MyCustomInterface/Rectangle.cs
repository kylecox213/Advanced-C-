﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyCustomInterface
{

    // Rectangle supports IShapePoints and IDraw3D interface types
    class Rectangle : Shape, IShapePoints, IDraw3D
    {
        public Rectangle() { }
        public Rectangle(string name) : base(name) { }

        public override void Draw()
        { Console.WriteLine("Drawing {0} the Rectangle", ShapeName); }

        public void Draw3D()
		{
            { Console.WriteLine("Drawing Rectangle in 3D"); }
		}

        // IShapePoints implementation
        public byte Points
        {
            get { return 4; }
        }
    }
}
