﻿using System;

namespace MyCustomInterface
{
	class Program
	{
		static void Main(string[] args)
		{

			// use casting to access the Draw() method from members
			Nonagon non = new Nonagon();
			IDrawToApp itfApp = non;
			itfApp.Draw();

			// shorthand notation that excludes the interface var if it is not needed
			Septagon sep = new Septagon();
			((IExplicitInterface.IDrawToForm)sep).Draw();

			// using the 'is' keyword in a conditional statement
			Octagon oct = new Octagon();
			if (oct is IExplicitInterface.IDrawToMemory dtm)
				dtm.Draw();
			Console.ReadLine();

			// Create array of IShapePoint compatible objects and iterate through the array
			// despite the overall diversity of the class heirarchy

			IShapePoints[] pointedObjects = { new Hexagon(), new Knife(), new Spoon(), new Pitchfork(), new Triangle() };
			foreach (IShapePoints i in pointedObjects)
				Console.WriteLine("This object has {0} points.", i.Points);
			Console.ReadLine();

			Shape[] variousShapes = { new Hexagon(), new Circle(), new Triangle("Jerry Butts"), new Circle("Jeffery Butts"), new Triangle("Johnny Butts"), new Rectangle("Jordy Butts") };

			IShapePoints firstPointedShape = FindFirstShapeWithPoints(variousShapes);
			Console.WriteLine("The Shape item has {0} points", firstPointedShape.Points);

			// Method that takes an array of Shape objects and returns a reference to
			// the first item that supports IShapePoints interface type

			static IShapePoints FindFirstShapeWithPoints(Shape[] shapes)
			{
				foreach (Shape s in shapes)
				{
					if (s is IShapePoints ip)
						return ip;
				}
				return null;
			}

			Hexagon hex = new Hexagon();
			Console.WriteLine("Points: {0}", hex.Points);
			Console.ReadLine();

			// Obtaining Interface References using the AS keyword

			Hexagon hex2 = new Hexagon("Jimmy Butts");
			IShapePoints frizzy = hex2 as IShapePoints;
			if (frizzy != null)
				Console.WriteLine("Points: {0}", frizzy.Points);
			else
				Console.WriteLine("\n...Looks like I just picked a whole bouquet of Whoopsie Daisies!\n");
			Console.ReadLine();

			// Invoking interface members at the object level and dynamically determine if a type supports a specific 
			// interface at runtime using an explicit cast

			Circle c = new Circle("Jasper Butts");
			IShapePoints fuzzy = null;
			try
			{
				fuzzy = (IShapePoints)c;
				Console.WriteLine(fuzzy.Points);
			}

			// Use structured exception handling to receive an InvalidCastException if the type
			// does not support the requested interface
			catch (InvalidCastException e)
			{
				Console.WriteLine(e.Message);
			}
			Console.ReadLine();

			Hexagon hex3 = new Hexagon("Jackie Butts");
			IShapePoints funky = hex3 as IShapePoints;
			if (funky != null)
				Console.WriteLine(funky.Points);
			else
				Console.WriteLine("That sucker aint pointy at all!!");
			Console.ReadLine();

			// Obtaining Interface References using the IS keyword

			Shape[] moreShapes = { new Hexagon(), new Circle(), new Triangle("Jodi Butts"), new Circle("Jenny Butts"), new Triangle("Jamie Butts"), new Rectangle("Jilly Butts") };

			for (int i = 0; i < moreShapes.Length; i++)
			{
				moreShapes[i].Draw();

				// Find which shapes are pointy
				if (variousShapes[i] is IShapePoints ip)
					Console.WriteLine(ip.Points);
				else
					Console.WriteLine("These shapes are pointless ->", moreShapes[i].ShapeName);

				// Test whether items in the Shape array supports the two new interfaces and, if so,
				// pass them into the DrawShapesIn3D() and DrawIn3D() methods for processing

				if (moreShapes[i] is IDrawShapesIn3D)
					DrawShapesIn3D((IDrawShapesIn3D)moreShapes[i]);
				else if
					(moreShapes[i] is IDraw3D)
					DrawIn3D((IDraw3D)moreShapes[i]);
				else
					Console.WriteLine("");
				Console.WriteLine();
			}
			Console.ReadLine();
		}

		// Define a method for accepting an IDrawShapesIn3D interface type as a parameter
		// for effectvely passing in any object implementing the IDraw3D interface type

		static void DrawShapesIn3D(IDrawShapesIn3D frothy)
		{
			Console.WriteLine("\n -> Drawing an IDrawShapesIn3D compatible type -> \n");
			frothy.DrawShapesIn3D();
		}

		// Define a method for accepting an IDraw3D interface type as a parameter
		// for effectvely passing in any object implementing the IDraw3D interface type

		static void DrawIn3D(IDraw3D frisky)
		{
			Console.WriteLine("\n -> Drawing an IDraw3D compatible type -> \n");
			frisky.Draw3D();
		}

	}
}
