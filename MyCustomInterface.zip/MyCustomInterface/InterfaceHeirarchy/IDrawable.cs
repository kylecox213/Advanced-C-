﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InterfaceHeirarchy
{
	public interface IDrawable
	{
		void Draw();
	}

	public interface IAdvancedDraw : IDrawable
	{
		void DrawInboundBox(int top, int bottom, int left, int right);
		void DrawUpsideDown();
	}
}
