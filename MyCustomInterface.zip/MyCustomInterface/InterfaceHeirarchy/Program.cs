﻿using System;

namespace InterfaceHeirarchy
{
	class Program
	{
		static void Main(string[] args)
		{

			// invoke each method, defined in the Bitmap class and extended through the IDrawable interface 
			// type, at the object level and extract a reference to each supported interface explicitly via casting

			BitmapImage myBitmap = new BitmapImage();
			myBitmap.Draw();
			myBitmap.DrawInboundBox(20, 30, 70, 80);
			myBitmap.DrawUpsideDown();

			IAdvancedDraw iAdvDraw = myBitmap as IAdvancedDraw;
			if (iAdvDraw != null)
				iAdvDraw.DrawUpsideDown();
			Console.ReadLine();

		}
	}
}
