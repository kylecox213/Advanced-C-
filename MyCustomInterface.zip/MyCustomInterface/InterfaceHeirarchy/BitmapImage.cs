﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InterfaceHeirarchy
{
	class BitmapImage : IAdvancedDraw
	{
		public void Draw()
		{
			Console.WriteLine("Something is being drawn...");
		}

		public void DrawInboundBox(int top, int bottom, int left, int right)
		{
			Console.WriteLine("Something is being drawn...in a box");

		}

		public void DrawUpsideDown()
		{
			Console.WriteLine("Something is being drawn...upside down");

		}
	}
}
