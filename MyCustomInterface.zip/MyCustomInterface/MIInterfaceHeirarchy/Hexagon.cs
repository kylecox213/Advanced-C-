﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MIInterfaceHeirarchy
{
	class Hexagon : IShape
	{
        public int GetNumberOfSides()
        { return 5; }

        public void Draw()
        { Console.WriteLine("Drawing..."); }

        public void Print()
        { Console.WriteLine("Prining..."); }
    }
}
