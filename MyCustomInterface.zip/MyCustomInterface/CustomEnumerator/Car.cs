﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CustomEnumerator
{
    class Car
    {
        public const int MaxSpeed = 143;

        public int CurrentSpeed { get; set; } = 0;
        public string CarName { get; set; } = "";

        private bool carIsDead;

        // A car has-a radio.
        private Radio theMusicBox = new Radio();

        public Car() { }
        public Car(string name, int speed)
        {
            CurrentSpeed = speed;
            CarName = name;
        }

        public void CrankTunes(bool state)
        {
            // Delegate request to inner object.
            theMusicBox.TurnOn(state);
        }

        #region Accelerate w/ exception. 

        // See if Car has overheated.
        public void Accelerate(int capacity)
        {
            // Throws predefined base class exception if an invalid parameter is passed in
            if (capacity < 0)
                throw new ArgumentOutOfRangeException("capacity", "Vehicle speed must be greater than zero!");

            if (carIsDead)
                Console.WriteLine("{0} is out of order...", CarName);
            else
            {
                CurrentSpeed += capacity;
                if (CurrentSpeed >= MaxSpeed)
                {
                    carIsDead = true;
                    CurrentSpeed = 0;

                    // We need to call the HelpLink property, thus we need
                    // to create a local variable before throwing the Exception object.
                    Exception ex = new Exception($"{CarName} has overheated!");
                    ex.HelpLink = "http://www.OReillys.com";

                    ex.Data.Add("TimeStamp", $"The car exploded into flames at {DateTime.Now}");
                    ex.Data.Add("Cause", "Exceeding the speed threshold for the vehicle.");
                    throw ex;
                    throw new Exception($"{CarName} has overheated");
                }
                else
                    Console.WriteLine("=> CurrentSpeed = {0}", CurrentSpeed);
            }
        }
        #endregion
    }
}
