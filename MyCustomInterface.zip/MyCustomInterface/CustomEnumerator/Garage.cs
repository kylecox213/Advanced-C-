﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CustomEnumerator
{
    public class Garage : IEnumerable
    {
        private Car[] carArray = new Car[6];

        // Fill with some Car objects upon startup.
        public Garage()
        {
            carArray[0] = new Car("Big Blue", 120);
            carArray[1] = new Car("Champagne Dream", 114);
            carArray[2] = new Car("Old Whitey", 106);
            carArray[3] = new Car("Red Freddy", 117);
            carArray[4] = new Car("Midight Rider", 141);
            carArray[5] = new Car("Mean Green", 155);
        }

        public IEnumerator GetEnumerator()
        {
            // Return the array object's IEnumerator.
            return carArray.GetEnumerator();
        }
    }
}
