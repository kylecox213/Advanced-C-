﻿using System;

namespace CustomEnumerator
{
	class Program
	{
		static void Main(string[] args)
		{
            Garage carLot = new Garage();

            // Iterate through each car in the collection?
            foreach (Car c in carLot)
            {

                Console.WriteLine("{0} is currently cruising at {1} MPH",
                  c.CarName, c.CurrentSpeed);
            }
            Console.ReadLine();
        }
	}
}
