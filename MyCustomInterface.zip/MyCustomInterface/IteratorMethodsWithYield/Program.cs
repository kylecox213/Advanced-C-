﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IteratorMethodsWithYield
{
    class Program
    {
        static void Main(string[] args)
        {

            // Utilizing the GetTheCars() named iterator allows the caller to obtain the subitems
            // in sequential order and in reverse order, if the incoming parameter is set to true

            Garage carLot = new Garage();

            // The next line demonstrates the delayed error error

            // IEnumerator carEnumerator = carLot.GetEnumerator();

            // Get the car items using GetEnumerator()
            foreach (Car c in carLot)
            {
                Console.WriteLine("{0} is going {1} MPH",
                  c.CarName, c.CurrentSpeed);
            }

            Console.WriteLine();

            // Get items in reverse using named iterator GetTheCars
            foreach (Car c in carLot.GetTheCars(true))
            {
                Console.WriteLine("{0} is going {1} MPH",
                  c.CarName, c.CurrentSpeed);
            }
            Console.ReadLine();
        }
    }
}