﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IteratorMethodsWithYield
{
    public class Garage : IEnumerable
    {
        private Car[] carArray = new Car[6];

        public Garage()
        {
            carArray[0] = new Car("Big Blue", 120);
            carArray[1] = new Car("Champagne Dream", 114);
            carArray[2] = new Car("Old Whitey", 106);
            carArray[3] = new Car("Red Freddy", 117);
            carArray[4] = new Car("Midight Rider", 141);
            carArray[5] = new Car("Mean Green", 155);
        }
		//public IEnumerator GetEnumerator()
		//{
		//	// This will not get thrown until MoveNext() method is called throw new Exception("This won't get called");

        //    // The implementation of GetEnumerator() iterates over the subitems using internal foreach logic and returns each Car object
        //    // using the yield return syntax. 

		//	foreach (Car c in carArray)
		//	{
		//		yield return c;
		//	}
		//}

		public IEnumerator GetEnumerator()
        {
            // This will get thrown immediately
            // throw new Exception("This will get called");

            return actualImplementation();

            // The private function
            IEnumerator actualImplementation()
            {
                foreach (Car c in carArray)
                {
                    yield return c;
                }
            }
        }

        // Create a custom named iterator
        public IEnumerable GetTheCars(bool returnReversed)
        {
            // Error checking
            return actualImplementation();

            IEnumerable actualImplementation()
            {
                // Return the items in reverse
                if (returnReversed)
                {
                    for (int i = carArray.Length; i != 0; i--)
                    {
                        yield return carArray[i - 1];
                    }
                }
                else
                {
                    // Return the items from the array
                    foreach (Car c in carArray)
                    {
                        yield return c;
                    }
                }
            }
        }
    }
}
