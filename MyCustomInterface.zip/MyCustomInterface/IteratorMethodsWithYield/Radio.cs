﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IteratorMethodsWithYield
{
    class Radio
    {
        public void TurnOn(bool on)
        {
            Console.WriteLine(on ? "Kick out the jams..." : "Hello, silence my old friend....");
        }
    }
}
