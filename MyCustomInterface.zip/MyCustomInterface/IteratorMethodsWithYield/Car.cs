﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IteratorMethodsWithYield
{
    class Car
    {
        public const int MaxSpeed = 143;

        public int CurrentSpeed { get; set; } = 0;
        public string CarName { get; set; } = "";

        private bool carIsDead;

        private Radio theMusicBox = new Radio();

        public Car() { }
        public Car(string name, int speed)
        {
            CurrentSpeed = speed;
            CarName = name;
        }

        public void CrankTunes(bool state)
        {
            theMusicBox.TurnOn(state);
        }

        #region Accelerate w/ exception. 

        public void Accelerate(int capacity)
        {
            if (capacity < 0)
                throw new ArgumentOutOfRangeException("capacity", "Vehicle speed must be greater than zero!");

            if (carIsDead)
                Console.WriteLine("{0} is out of order...", CarName);
            else
            {
                CurrentSpeed += capacity;
                if (CurrentSpeed >= MaxSpeed)
                {
                    carIsDead = true;
                    CurrentSpeed = 0;

                    // We need to call the HelpLink property, thus we need
                    // to create a local variable before throwing the Exception object.
                    Exception ex = new Exception($"{CarName} has overheated!");
                    ex.HelpLink = "http://www.OReillys.com";

                    ex.Data.Add("TimeStamp", $"The car exploded into flames at {DateTime.Now}");
                    ex.Data.Add("Cause", "Exceeding the speed threshold for the vehicle.");
                    throw ex;
                    throw new Exception($"{CarName} has overheated");
                }
                else
                    Console.WriteLine("=> CurrentSpeed = {0}", CurrentSpeed);
            }
        }
        #endregion
    }
}