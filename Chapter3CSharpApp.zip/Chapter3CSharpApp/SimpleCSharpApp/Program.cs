﻿using System;
using System.Windows;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Numerics;

namespace SimpleCSharpApp
{
	class Program
	{
		static int Main(string[] args)
		{
			ConsoleColor prevFGColor = Console.ForegroundColor;
			Console.ForegroundColor = ConsoleColor.Yellow;

			ConsoleColor prevBGColor = Console.BackgroundColor;
			Console.BackgroundColor = ConsoleColor.DarkBlue;

			Console.WriteLine("Here are two of the most difficult tongue twisters in the world:");
			Console.WriteLine("");
			Console.WriteLine("");
			Console.WriteLine("Tongue Twister #1");
			Console.WriteLine("");
			Console.WriteLine("Pad kid poured curd pulled cod");
			Console.WriteLine("");
			Console.WriteLine("");
			Console.WriteLine("Tongue Twister #2");

			Console.WriteLine("");
			Console.WriteLine("How can a clam cram in a clean cream can?");
			Console.WriteLine("");
			Console.WriteLine("");

			Console.ForegroundColor = prevFGColor;
			Console.BackgroundColor = prevBGColor;


			for (int i = 0; i < args.Length; i++)
				Console.WriteLine("Arg: {0}", args[i]);

			foreach (string arg in args)
				Console.WriteLine("Arg: {0}", arg);


			string[] theArgs = Environment.GetCommandLineArgs();
			foreach (string arg in theArgs)
				Console.WriteLine("Arg: {0}", arg);

			ShowEnvironmentDetails();

			Console.ReadLine();

			// Return an arbitrary error code.
			return -1;
		}


		private static void ShowEnvironmentDetails()
		{

			// Print out the drives on this machine
			// along with other useful details.
			foreach (string drive in Environment.GetLogicalDrives())
				Console.WriteLine("Drive: {0}", drive);

			Console.WriteLine("OS: {0}", Environment.OSVersion);
			Console.WriteLine("Number of processors: {0}",
				Environment.ProcessorCount);
			Console.WriteLine(".NET Version: {0}",
				Environment.Version);
		}

		//---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
		//---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

		//static void Main(string[] args)
		//{
		//	Console.WriteLine("***** Basic Console I/O *****");
		//	GetUserData();
		//	FormatNumericalData();
		//	Console.ReadLine();
		//}

		//#region Get user data
		//private static void GetUserData()
		//{
		//	// Get name and age.
		//	Console.Write("Please enter your name: ");
		//	string userName = Console.ReadLine();
		//	Console.Write("Please enter your age: ");
		//	string userAge = Console.ReadLine();

		//	// Change echo color, just for fun.
		//	ConsoleColor prevColor = Console.ForegroundColor;
		//	Console.ForegroundColor = ConsoleColor.Yellow;

		//	// Echo to the console.
		//	Console.WriteLine("Hello {0}! You are {1} years old.",
		//		userName, userAge);

		//	// Restore previous color.
		//	Console.ForegroundColor = prevColor;
		//}
		//#endregion

		//#region Format numerical data
		//// Now make use of some format tags.
		//static void FormatNumericalData()
		//{
		//	Console.WriteLine("The value 99999 in various formats:");
		//	Console.WriteLine("c format: {0:c}", 99999);
		//	Console.WriteLine("d9 format: {0:d9}", 99999);
		//	Console.WriteLine("f3 format: {0:f3}", 99999);
		//	Console.WriteLine("n format: {0:n}", 99999);
		//	// Notice that upper- or lowercasing for hex
		//	// determines if letters are upper- or lowercase.
		//	Console.WriteLine("E format: {0:E}", 99999);
		//	Console.WriteLine("e format: {0:e}", 99999);
		//	Console.WriteLine("X format: {0:X}", 99999);
		//	Console.WriteLine("x format: {0:x}", 99999);

		//	Console.WriteLine("G format: {0:G}", 99999);
		//	Console.WriteLine("g format: {0:N}", 99999);
		//	Console.WriteLine("C format: {0:C}", 99999);
		//	Console.WriteLine("D7 format: {0:d7}", 99999);
		//	Console.WriteLine("F5 format: {0:F5}", 99999);
		//	Console.WriteLine("N format: {0:N}", 99999);

		//	Console.WriteLine("{0}, {3}, {1}, {2}", 8, 7, 6, 5);
		//	Console.WriteLine("{0}, {1}, {2}, {3}", 8, 7, 6, 5);

		//	Console.WriteLine("{0}, {1}, {2}, {3}, {4}, {5}", " Eww", " You", " just", " stepped", " in", " it");
		//	Console.WriteLine("{3}, {5}, {1}, {2}, {0}, {4}", " Eww", " You", " just", " stepped", " in", " it");
		//}

		//#endregion

		//// A reference to Presentation Foundation DLL is required to compile this line of code

		//static void DisplayMessage()
		//{
		//	string userMessage = string.Format("100000 in hex is {0:x}", 100000);
		//}

		//---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
		//---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

		//static void Main(string[] args)
		//{
		//	Console.WriteLine("***** Fun with Basic Data Types *****\n");
		//	LocalVarDeclarations();
		//	DefaultDeclarations();
		//	NewingDataTypes();
		//	ObjectFunctionality();
		//	DataTypeFunctionality();
		//	CharFunctionality();
		//	ParseFromStrings();
		//	ParseFromStringsWithTryParse();
		//	UseDatesAndTimes();
		//	UseBigInteger();
		//	DigitSeparators();
		//	BinaryLiterals();
		//	Console.ReadLine();
		//}

		//#region Local variable declarations

		//static void LocalVarDeclarations()
		//{
		//	Console.WriteLine("=> Data Declarations:");
		//	// Local variables are declared and initialized as follows:
		//	// dataType varName = initialValue;
		//	int myInt = 0;

		//	string myString;
		//	myString = "This is my character data";

		//	// Declare 3 bools on a single line.
		//	bool b1 = true, b2 = false, b3 = b1;
		//	bool a1 = true;

		//	// Very verbose manner in which to declare a bool.
		//	System.Boolean b4 = false;

		//	Console.WriteLine("Your data: {0}, {1}, {2}, {3}, {4}, {5}, {6}",
		//	  myInt, myString, b1, b2, b3, b4, a1);
		//	Console.WriteLine();
		//}
		//static void DefaultDeclarations()
		//{
		//	Console.WriteLine("=> Default Declarations:");
		//	int myInt = default;
		//}

		//static void NewingDataTypes()
		//{
		//	Console.WriteLine("=> Using new to create variables:");
		//	bool b = new bool(); // Set to false.
		//	int i = new int(); // Set to 0.
		//	double d = new double(); // Set to 0.
		//	DateTime dt = new DateTime(); // Set to 1/1/0001 12:00:00 AM
		//	char c = new char();
		//	Console.WriteLine("{0}, {1}, {2}, {3}, {4}", b, i, d, dt, c);
		//	Console.WriteLine();
		//}

		//#endregion

		//#region Test Object functionality

		//static void ObjectFunctionality()
		//{
		//	Console.WriteLine("=> System.Object Functionality:");
		//	// A C# int is really a shorthand for System.Int32.
		//	// which inherits the following members from System.Object.
		//	Console.WriteLine("12.GetHashCode() = {0}", 12.GetHashCode());
		//	Console.WriteLine("12.Equals(23) = {0}", 12.Equals(23));
		//	Console.WriteLine("12.ToString() = {0}", 12.ToString());
		//	Console.WriteLine("12.GetType() = {0}", 12.GetType());

		//	Console.WriteLine("12.CompareTo() = {0}", 12.CompareTo(233));
		//	Console.WriteLine("12.GetTypeCode() = {0}", 12.GetTypeCode());

		//	Console.WriteLine();
		//}

		//#endregion

		//#region Test data type functionality

		//static void DataTypeFunctionality()
		//{
		//	Console.WriteLine("=> Data type Functionality:");
		//	Console.WriteLine("Max of int: {0}", int.MaxValue);
		//	Console.WriteLine("Min of int: {0}", int.MinValue);
		//	Console.WriteLine("Max of int: {0}", int.MaxValue);
		//	Console.WriteLine("Min of int: {0}", int.MinValue);
		//	Console.WriteLine("Max of double: {0}", double.MaxValue);
		//	Console.WriteLine("Min of double: {0}", double.MinValue);
		//	Console.WriteLine("double.Epsilon: {0}", double.Epsilon);
		//	Console.WriteLine("double.PositiveInfinity: {0}",
		//	  double.PositiveInfinity);
		//	Console.WriteLine("double.NegativeInfinity: {0}",
		//	  double.NegativeInfinity);
		//	Console.WriteLine("bool.FalseString: {0}", bool.FalseString);
		//	Console.WriteLine("bool.TrueString: {0}", bool.TrueString);
		//	Console.WriteLine();
		//}

		//#endregion

		//#region Test char data type

		//static void CharFunctionality()
		//{
		//	Console.WriteLine("=> char type Functionality:");
		//	char myChar = 'a';
		//	Console.WriteLine("char.IsDigit('a'): {0}", char.IsDigit(myChar));
		//	Console.WriteLine("char.IsLetter('a'): {0}", char.IsLetter(myChar));
		//	Console.WriteLine("char.IsWhiteSpace('Hello There', 5): {0}",
		//	  char.IsWhiteSpace("Hello There", 5));
		//	Console.WriteLine("char.IsWhiteSpace('Hello There', 6): {0}",
		//	  char.IsWhiteSpace("Hello There", 6));
		//	Console.WriteLine("char.IsPunctuation('?'): {0}",
		//	  char.IsPunctuation('?'));
		//	Console.WriteLine();
		//}

		//#endregion

		//#region Parsing data

		//static void ParseFromStrings()
		//{
		//	Console.WriteLine("=> Data type parsing:");
		//	bool b = bool.Parse("True");
		//	Console.WriteLine("Value of b: {0}", b);
		//	double d = double.Parse("99.884");
		//	Console.WriteLine("Value of d: {0}", d);
		//	int i = int.Parse("8");
		//	Console.WriteLine("Value of i: {0}", i);
		//	char c = Char.Parse("w");
		//	Console.WriteLine("Value of c: {0}", c);
		//	Console.WriteLine();
		//}

		//static void ParseFromStringsWithTryParse()
		//{
		//	Console.WriteLine("=> Data type parsing with TryParse:");
		//	if (bool.TryParse("True", out bool b))
		//	{
		//		Console.WriteLine("Value of b: {0}", b);
		//	}
		//	string value = "Hello";
		//	if (double.TryParse(value, out double d))
		//	{
		//		Console.WriteLine("Value of d: {0}", d);
		//	}
		//	else
		//	{
		//		Console.WriteLine("Failed to convert the input ({0}) to a double", value);
		//	}
		//	Console.WriteLine();
		//}

		//#endregion

		//#region Work with dates / times

		//static void UseDatesAndTimes()
		//{
		//	Console.WriteLine("=> Dates and Times:");
		//	// This constructor takes (year, month, day)
		//	DateTime dt = new DateTime(2021, 08, 26);

		//	// What day of the month is this?
		//	Console.WriteLine("The day of {0} is {1}", dt.Date, dt.DayOfWeek, dt.Month);
		//	dt = dt.AddMonths(2); // Month is now December.
		//	Console.WriteLine("Daylight savings: {0}", dt.IsDaylightSavingTime());

		//	// This constructor takes (hours, minutes, seconds)
		//	TimeSpan ts = new TimeSpan(2, 51, 0);
		//	Console.WriteLine(ts);

		//	// Subtract 15 minutes from the current TimeSpan and
		//	// print the result.
		//	Console.WriteLine(ts.Subtract(new TimeSpan(0, 15, 0)));
		//	Console.WriteLine();
		//}

		//#endregion

		//#region Use BigInteger

		//static void UseBigInteger()
		//{
		//	Console.WriteLine("=> Use BigInteger:");
		//	BigInteger biggy = BigInteger.Parse("9999999999999999999999999999999999999999999999");
		//	BigInteger largeO = BigInteger.Parse("1209234874587609129823874512092398457601292384");

		//	Console.WriteLine("Value of biggy is {0}", biggy);
		//	Console.WriteLine("value of largeO is {0}", largeO);
		//	Console.WriteLine("Is biggy an even value?: {0}", biggy.IsEven);
		//	Console.WriteLine("Is biggy a power of two?: {0}", biggy.IsPowerOfTwo);
		//	Console.WriteLine("Is biggy a power of two?: {0}", biggy.IsZero);

		//	Console.WriteLine("Is biggy a power of two?: {0}", biggy.IsOne);

		//	BigInteger reallyBig = BigInteger.Multiply(biggy,
		//	  BigInteger.Parse("8888888888888888888888888888888888888888888"));
		//	BigInteger reallyBig2 = biggy * reallyBig;

		//	Console.WriteLine("Value of reallyBig is {0}", reallyBig);


		//	// ********    not sure what code violation requires explicit casting for BigInteger.Parse()

		//	BigInteger reallyLarge = BigInteger.Add(largeO, BigInteger.Parse("09121209219982398239823982388734873487348734"));

		//	Console.WriteLine("reallyBig = {0}", reallyBig); 
		//	Console.WriteLine("largeO = {0}", largeO);
		//	Console.WriteLine("reallyBig2 = {0}", reallyBig2);
		//	Console.WriteLine("biggy = {0}", biggy);
		//	Console.WriteLine("reallyLarge = {0}", reallyLarge);
		//}

		//#endregion

		//#region Use Digit Separators

		//static void DigitSeparators()
		//{
		//	Console.WriteLine("=> Use Digit Separators:");
		//	Console.Write("Integer:");
		//	Console.WriteLine(123_456);
		//	Console.Write("Long:");
		//	Console.WriteLine(123_456_789L);
		//	Console.Write("Float:");
		//	Console.WriteLine(123_456.1234F);
		//	Console.Write("Double:");
		//	Console.WriteLine(123_456.12);
		//	Console.Write("Decimal:");
		//	Console.WriteLine(123_456.12M);
		//}

		//#endregion

		//#region Use Binary Literals

		//private static void BinaryLiterals()
		//{
		//	Console.WriteLine("=> Use Binary Literals:");
		//	Console.WriteLine("Sixteen: {0}", 0b0001_0000);
		//	Console.WriteLine("Thirty Two: {0}", 0b0010_0000);
		//	Console.WriteLine("Sixty Four: {0}", 0b0100_0000);
		//}

		//#endregion

		//---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
		//---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

		//static void Main(string[] args)
		//{
		//	Console.WriteLine("***** Fun with Strings *****\n");
		//	BasicStringFunctionality();
		//	StringConcatenation();
		//	EscapeChars();
		//	StringEquality();
		//	StringEqualitySpecifyingCompareRules();
		//	StringsAreImmutable();
		//	FunWithStringBuilder();
		//	StringInterpolation();
		//	Console.ReadLine();
		//}

		//#region String basics

		//static void BasicStringFunctionality()
		//{
		//	string firstName = "Freddy";
		//	Console.WriteLine("Value of firstName: {0}", firstName);
		//	Console.WriteLine("firstName has {0} characters.", firstName.Length);
		//	Console.WriteLine("firstName in uppercase: {0}", firstName.ToUpper());
		//	Console.WriteLine("firstName in lowercase: {0}", firstName.ToLower());
		//	Console.WriteLine("firstName contains the letter y?: {0}",
		//		firstName.Contains("y"));
		//	Console.WriteLine("New first name: {0}", firstName.Replace("dy", ""));
		//	Console.WriteLine();
		//}

		//#endregion

		//#region Concatenation

		//static void StringConcatenation()
		//{
		//	Console.WriteLine("=> String concatenation:");
		//	string s1 = "Programming the ";
		//	string s2 = "PsychoDrill (PTP)";
		//	string s3 = s1 + s2;
		//	Console.WriteLine(s3);
		//	Console.WriteLine();
		//}

		//#endregion

		//#region Escape Chars

		//static void EscapeChars()
		//{
		//	Console.WriteLine("=> Escape characters:\a");
		//	string strWithTabs = "Model\tColor\tSpeed\tPet Name\a ";
		//	Console.WriteLine(strWithTabs);

		//	Console.WriteLine("Everyone loves \"Hello World\"\a ");
		//	Console.WriteLine("C:\\MyApp\\bin\\Debug\a ");

		//	// Adds a total of 4 blank lines (then beep again!).
		//	Console.WriteLine("All finished.\n\n\n\a ");
		//	Console.WriteLine();

		//	// The following string is printed verbatim
		//	// thus, all escape characters are displayed.
		//	Console.WriteLine(@"C:\MyApp\bin\Debug");

		//	// White space is preserved with verbatim strings.
		//	string myLongString = @"This is a very
		//         very
		//              very
		//                   long string";
		//	Console.WriteLine(myLongString);
		//	Console.WriteLine();
		//	Console.WriteLine(@"Cerebus said ""Darrr! Pret-ty sun-sets""");
		//}

		//#endregion

		//#region String Equality

		//static void StringEquality()
		//{
		//	Console.WriteLine("=> String equality:");
		//	string s1 = "Hello!";
		//	string s2 = "Yo!";
		//	Console.WriteLine("s1 = {0}", s1);
		//	Console.WriteLine("s2 = {0}", s2);
		//	Console.WriteLine();

		//	// Test these strings for equality.
		//	Console.WriteLine("s1 == s2: {0}", s1 == s2);
		//	Console.WriteLine("s1 == Hello!: {0}", s1 == "Hello!");
		//	Console.WriteLine("s1 == HELLO!: {0}", s1 == "HELLO!");
		//	Console.WriteLine("s1 == hello!: {0}", s1 == "hello!");
		//	Console.WriteLine("s1.Equals(s2): {0}", s1.Equals(s2));
		//	Console.WriteLine("Yo.Equals(s2): {0}", "Yo!".Equals(s2));
		//	Console.WriteLine();
		//}

		//static void StringEqualitySpecifyingCompareRules()
		//{
		//	Console.WriteLine("=> String equality (Case Insensitive:");
		//	string s1 = "Hello!";
		//	string s2 = "HELLO!";
		//	Console.WriteLine("s1 = {0}", s1);
		//	Console.WriteLine("s2 = {0}", s2);
		//	Console.WriteLine();

		//	// Check the results of changing the default compare rules.
		//	Console.WriteLine("Default rules: s1={0},s2={1}s1.Equals(s2): {2}", s1, s2, s1.Equals(s2));
		//	Console.WriteLine("Ignore case: s1.Equals(s2, StringComparison.OrdinalIgnoreCase): {0}", s1.Equals(s2, StringComparison.OrdinalIgnoreCase));
		//	Console.WriteLine("Ignore case, Invariant Culture: s1.Equals(s2, StringComparison.InvariantCultureIgnoreCase): {0}", s1.Equals(s2, StringComparison.InvariantCultureIgnoreCase));
		//	Console.WriteLine();
		//	Console.WriteLine("Default rules: s1={0},s2={1} s1.IndexOf(\"E\"): {2}", s1, s2, s1.IndexOf("E"));
		//	Console.WriteLine("Ignore case: s1.IndexOf(\"E\", StringComparison.OrdinalIgnoreCase): {0}", s1.IndexOf("E", StringComparison.OrdinalIgnoreCase));
		//	Console.WriteLine("Ignore case, Invariant Culture: s1.IndexOf(\"E\", StringComparison.InvariantCultureIgnoreCase): {0}", s1.IndexOf("E", StringComparison.InvariantCultureIgnoreCase));
		//	Console.WriteLine();
		//}

		//#endregion

		//#region Immutable test

		//static void StringsAreImmutable()
		//{
		//	// Set initial string value.
		//	string s1 = "This is my string.";
		//	Console.WriteLine("s1 = {0}", s1);

		//	// Uppercase s1?
		//	string upperString = s1.ToUpper();
		//	Console.WriteLine("upperString = {0}", upperString);

		//	// Nope! s1 is in the same format!
		//	Console.WriteLine("s1 = {0}", s1);

		//	string s2 = "My other string";
		//	s2 = "New string value";
		//	Console.WriteLine(s2);
		//}

		//#endregion

		//#region StringBuilder

		//static void FunWithStringBuilder()
		//{
		//	Console.WriteLine("=> Using the StringBuilder:");

		//	// Make a StringBuilder with an initial size of 256.
		//	StringBuilder sb = new StringBuilder("**** Fantastic Games ****", 256);

		//	sb.Append("\n");
		//	sb.AppendLine("Super Metroid");
		//	sb.AppendLine("Call of Duty: Modern Warfare 2");
		//	sb.AppendLine("Goldeneye");
		//	sb.AppendLine("Mega Man II");
		//	Console.WriteLine(sb.ToString());

		//	sb.Replace("2", "Chrono Trigger");
		//	Console.WriteLine(sb.ToString());
		//	Console.WriteLine("sb has {0} chars.", sb.Length);
		//	Console.WriteLine();
		//}

		//#endregion

		//#region String interpolation

		//static void StringInterpolation()
		//{
		//	// Some local variables we will plug into our larger string
		//	int age = 106;
		//	string name = "Smacky";

		//	// Using curly bracket syntax.
		//	string greeting = string.Format("\Top o' the morning {0} you are {1} years old. Isn't that just great?!", name.ToUpper(), age);
		//	Console.WriteLine(greeting);

		//	// Using string interpolation
		//	string greeting2 = $"\tHowdy there, {name.ToUpper()} you are {age} years old.";
		//	Console.WriteLine(greeting2);

		//	string greeting3 = $"\tExcuse me, {name.ToLower()} you are {age} times past the legal limit. I am going to have to ask you to step out of the vehicle and play a round of Gin.";
		//	Console.WriteLine(greeting3);
		//}

		//#endregion

		//---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
		//---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

		//static void Main(string[] args)
		//{
		//	Console.WriteLine("***** Fun with Implicit Typing *****");
		//	DeclareImplicitVars();
		//	QueryOverInts();
		//	Console.WriteLine();
		//	Console.ReadKey();
		//}

		//#region Implicit data typing

		//static void DeclareImplicitVars()
		//{
		//	// Implicitly typed local variables.
		//	var myInt = 0;
		//	var myBool = true;
		//	var myString = "Time, marches on...";

		//	// Print out the underlying type.
		//	Console.WriteLine("myInt is a: {0}", myInt.GetType().Name);
		//	Console.WriteLine("myBool is a: {0}", myBool.GetType().Name);
		//	Console.WriteLine("myString is a: {0}", myString.GetType().Name);
		//}

		//static int GetAnInt()
		//{
		//	var retVal = 9;
		//	return retVal;
		//}

		//static void ImplicitTypingIsStrongTyping()
		//{
		//	// The compiler knows "s" is a System.String.
		//	var s = "This variable can only hold string data!";
		//	s = "This is fine...";

		//	// Can invoke any member of the underlying type.
		//	string upper = s.ToUpper();

		//	// Error! Can't assign numerical data to a a string!
		//	// s = 44;
		//}

		//#endregion

		//#region LINQ example
		//static void QueryOverInts()
		//{
		//	int[] numbers = { 10, 20, 30, 40, 1, 2, 3, 8 };
		//	var subset = from i in numbers where i < 10 select i;

		//	Console.Write("Values in subset: ");
		//	foreach (var i in subset)
		//	{
		//		Console.Write("{0} ", i);
		//	}
		//	Console.WriteLine();

		//	// Hmm...what type is subset?
		//	Console.WriteLine("subset is a: {0}", subset.GetType().Name);
		//	Console.WriteLine("subset is defined in: {0}", subset.GetType().Namespace);
		//}

		//#endregion

		//---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
		//---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

		//	static void Main(string[] args)
		//	{
		//		Console.WriteLine("***** Loops and Choices *****\n");
		//		ForAndForEachLoop();
		//		VarInForeachLoop();
		//		ExecuteWhileLoop();
		//		ExecuteDoWhileLoop();
		//		ExecuteIfElse();
		//		ExecuteIfElseUsingConditionalOperator();
		//		ExecuteSwitch();
		//		ExecuteSwitchOnString();
		//		SwitchOnEnumExample();
		//		ExecutePatternMatchingSwitch();
		//		ExecutePatternMatchingSwitchWithWhen();
		//		Console.ReadLine();
		//	}

		//	#region For / foreach loops

		//	// A basic for loop.
		//	static void ForAndForEachLoop()
		//	{
		//		// Note! "i" is only visible within the scope of the for loop.
		//		for (int i = 0; i < 8; i++)
		//		{
		//			Console.WriteLine(i);
		//		}
		//		// "i" is not visible here.
		//		Console.WriteLine();

		//		string[] carTypes = { "Ford", "BMW", "Yugo", "Honda", "Dodge", "GMC" };
		//		foreach (string c in carTypes)
		//			Console.WriteLine(c);
		//		Console.WriteLine();

		//		int[] myInts = { 10, 20, 30, 40 };
		//		foreach (int i in myInts)
		//			Console.WriteLine(i);

		//		Console.WriteLine();
		//	}

		//	#endregion

		//	#region Var keyword in foreach

		//	static void VarInForeachLoop()
		//	{
		//		int[] myInts = { 10, 20, 30, 40 };

		//		// Use "var" in a standard foreach loop.
		//		foreach (var item in myInts)
		//		{
		//			Console.WriteLine(item);
		//		}

		//		Console.WriteLine();
		//	}

		//	#endregion

		//	#region while loop

		//	static void ExecuteWhileLoop()
		//	{
		//		string userIsDone = "";

		//		// Test on a lower-class copy of the string.
		//		while (userIsDone.ToLower() != "yes")
		//		{
		//			Console.Write("Are you done? [yes] [no]: ");
		//			userIsDone = Console.ReadLine();
		//			Console.WriteLine("In while loop");
		//		}
		//		Console.WriteLine();
		//	}

		//	#endregion

		//	#region do/while loop

		//	static void ExecuteDoWhileLoop()
		//	{
		//		string userIsDone = "";

		//		do
		//		{
		//			Console.WriteLine("In do/while loop");
		//			Console.Write("Are you done? [yes] [no]: ");
		//			userIsDone = Console.ReadLine();
		//		} while (userIsDone.ToLower() != "yes"); // Note the semicolon!

		//		Console.WriteLine();
		//	}

		//	#endregion

		//	#region If/else

		//	static void ExecuteIfElse()
		//	{
		//		string stringData = "My textual data";
		//		if (stringData.Length > 0)
		//		{
		//			Console.WriteLine("string is greater than 0 characters");
		//		}
		//		else
		//		{
		//			Console.WriteLine("string is not greater than 0 characters");
		//		}
		//		Console.WriteLine();
		//	}

		//	private static void ExecuteIfElseUsingConditionalOperator()
		//	{
		//		string stringData = "My textual data";
		//		Console.WriteLine(stringData.Length > 0
		//		  ? "string is greater than 0 characters"
		//		  : "string is not greater than 0 characters");
		//		Console.WriteLine();
		//	}

		//	private static void ExecuteAnotherIfElseUsingConditionalOperator()
		//	{
		//		int intData = 9;
		//		Console.WriteLine(intData > 0
		//? "string is greater than 0 characters"
		//		  : "string is not greater than 0 characters");
		//		Console.WriteLine();
		//	}

		//	#endregion

		//	#region C# 6 switch statements

		//	// Switch on a numerical value.
		//	static void ExecuteSwitch()
		//	{
		//		Console.WriteLine("1 [C#], 2 [VB]");
		//		Console.Write("Please pick your language preference: ");

		//		string langChoice = Console.ReadLine();
		//		int n = int.Parse(langChoice);

		//		switch (n)
		//		{
		//			case 1:
		//				Console.WriteLine("Good choice, C# is a fine language.");
		//				break;
		//			case 2:
		//				Console.WriteLine("VB: OOP, multithreading, and more!");
		//				break;
		//			default:
		//				Console.WriteLine("Well...good luck with that!");
		//				break;
		//		}
		//		Console.WriteLine();
		//	}

		//	static void ExecuteSwitchOnString()
		//	{
		//		Console.WriteLine("C# or VB");
		//		Console.Write("Please pick your language preference: ");
		//		string langChoice = Console.ReadLine();
		//		switch (langChoice)
		//		{
		//			case "C#":
		//				Console.WriteLine("Good choice, C# is a fine language.");
		//				break;
		//			case "VB":
		//				Console.WriteLine("VB: OOP, multithreading and more!");
		//				break;
		//			default:
		//				Console.WriteLine("Well...good luck with that!");
		//				break;
		//		}
		//		Console.WriteLine();
		//	}

		//	static void SwitchOnEnumExample()
		//	{
		//		Console.Write("Enter your favorite day of the week: ");
		//		DayOfWeek favDay;

		//		try
		//		{
		//			favDay = (DayOfWeek)Enum.Parse(typeof(DayOfWeek), Console.ReadLine());
		//		}
		//		catch (Exception)
		//		{
		//			Console.WriteLine("Bad input!");
		//			return;
		//		}

		//		switch (favDay)
		//		{
		//			case DayOfWeek.Sunday:
		//				Console.WriteLine("Football!! We got it this year!");
		//				break;
		//			case DayOfWeek.Monday:
		//				Console.WriteLine("Looks like someone has a case of the Mondays.");
		//				break;
		//			case DayOfWeek.Tuesday:
		//				Console.WriteLine("Happy Hour!");
		//				break;
		//			case DayOfWeek.Wednesday:
		//				Console.WriteLine("Guess what day it is????");
		//				break;
		//			case DayOfWeek.Thursday:
		//				Console.WriteLine("It is an impediment that is blocking Friday...Nuff said.");
		//				break;
		//			case DayOfWeek.Friday:
		//				Console.WriteLine("Yes, Friday the 13th is scary!");
		//				break;
		//			case DayOfWeek.Saturday:
		//				Console.WriteLine("College football? Yes, please.");
		//				break;
		//		}
		//		Console.WriteLine();
		//	}

		//	public static void SwitchWithGoto()
		//	{
		//		var foo = 5;
		//		switch (foo)
		//		{
		//			case 1:
		//				//do something
		//				goto case 2;
		//			case 2:
		//				//do something else
		//				break;
		//			case 3:
		//				//yet another action
		//				goto default;
		//			default:
		//				//default action
		//				break;
		//		}
		//	}

		//	#endregion

		//	#region C# 7 switch statements

		//	static void ExecutePatternMatchingSwitch()
		//	{
		//		Console.WriteLine("1 [Integer (5)], 2 [String (\"Hi\")], 3 [Decimal (2.5)]");
		//		Console.Write("Please choose an option: ");
		//		string userChoice = Console.ReadLine();
		//		object choice;
		//		//This is a standard constant pattern switch statement to set up the example
		//		switch (userChoice)
		//		{
		//			case "1":
		//				choice = 5;
		//				break;
		//			case "2":
		//				choice = "Hi";
		//				break;
		//			case "3":
		//				choice = 2.5;
		//				break;
		//			default:
		//				choice = 5;
		//				break;
		//		}
		//		//This is new the pattern matching switch statement
		//		switch (choice)
		//		{
		//			case int i:
		//				Console.WriteLine("Your choice is an integer {0}.", i);
		//				break;
		//			case string s:
		//				Console.WriteLine("Your choice is a string. {0}", s);
		//				break;
		//			case decimal d:
		//				Console.WriteLine("Your choice is a decimal. {0}", d);
		//				break;
		//			default:
		//				Console.WriteLine("Your choice is something else");
		//				break;
		//		}
		//		Console.WriteLine();
		//	}

		//	static void ExecutePatternMatchingSwitchWithWhen()
		//	{
		//		Console.WriteLine("1 [C#], 2 [VB]");
		//		Console.Write("Please pick your language preference: ");

		//		object langChoice = Console.ReadLine();
		//		var choice = int.TryParse(langChoice.ToString(), out int c) ? c : langChoice;

		//		switch (choice)
		//		{
		//			case int i when i == 2:
		//			case string s when s.Equals("VB", StringComparison.OrdinalIgnoreCase):
		//				Console.WriteLine("VB: OOP, multithreading, and more!");
		//				break;
		//			case int i when i == 1:
		//			case string s when s.Equals("C#", StringComparison.OrdinalIgnoreCase):
		//				Console.WriteLine("Good choice, C# is a fine language.");
		//				break;
		//			default:
		//				Console.WriteLine("Well...good luck with that!");
		//				break;
		//		}
		//		Console.WriteLine();
		//	}

		//	#endregion

		//-------------------------------------------------------------------------------------------------------------------------------
		//-------------------------------------------------------------------------------------------------------------------------------

		//		static void Main(string[] args)
		//		{
		//			Console.WriteLine("***** Fun with type conversions *****\n");
		//			short numb1 = 30000, numb2 = 30000;

		//			// Explicitly cast the int into a short (and allow loss of data).
		//			short answer = (short)Add(numb1, numb2);

		//			Console.WriteLine("{0} + {1} = {2}",
		//				numb1, numb2, answer);
		//			NarrowingAttempt();
		//			ProcessBytes();
		//			NarrowWithConvert();
		//			Console.ReadLine();
		//		}

		//		static int Add(int x, int y)
		//		{ return x + y; }

		//		#region Narrowing / Widening examples

		//		static void NarrowingAttempt()
		//		{
		//			byte myByte = 0;
		//			int myInt = 200;

		//			// Explicitly cast the int into a byte (no loss of data).
		//			myByte = (byte)myInt;
		//			Console.WriteLine("Value of myByte: {0}", myByte);
		//		}

		//		static void ProcessBytes()
		//		{
		//			byte b1 = 100;
		//			byte b2 = 250;

		//			// This time, tell the compiler to add CIL code
		//			// to throw an exception if overflow/underflow
		//			// takes place.
		//			try
		//			{
		//				byte sum = checked((byte)Add(b1, b2));
		//				Console.WriteLine("sum = {0}", sum);
		//			}
		//			catch (OverflowException ex)
		//			{
		//				Console.WriteLine(ex.Message);
		//			}
		//		}

		//		static void NarrowWithConvert()
		//		{
		//			byte myByte = 0;
		//			int myInt = 200;
		//			myByte = Convert.ToByte(myInt);
		//			Console.WriteLine("Value of myByte: {0}", myByte);
		//		}

		//		#endregion
		//	}

		//	#region Bad use of var!

		//	// Uncomment to see compile errors.
		//	//class ThisWillNeverCompile
		//	//{
		//	//    // Error! var cannot be used as field data!
		//	//    private var myInt = 10;

		//	//    // Error! var cannot be used as a return value
		//	//    // or parameter type!
		//	//    public var MyMethod(var x, var y) { }
		//	//}

		//	#endregion
	}
}


