﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SimpleCSharpConsoleApp
{
    class Program
    {
        static void Main(string[] args)
        {
            // Set up Console UI (CUI)
            Console.Title = "Mi aplicacion escrita en espanol";
            Console.ForegroundColor = ConsoleColor.DarkRed;
            Console.BackgroundColor = ConsoleColor.DarkBlue;
            Console.WriteLine("**************************************************");
            Console.WriteLine("***** Bienvenidos a mi increible aplicacion!! *****");
            Console.WriteLine("**************************************************");
            Console.BackgroundColor = ConsoleColor.Green;

            // Wait for Enter key to be pressed.
            Console.ReadLine();
            MessageBox.Show("Eso es todo amigos!!");
        }
    }
}