﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SimpleCSharpConsoleApp
{
	public class LuxuryCar : Car
	{
		public string GetFavoriteFood()
		{
			FavoriteFood = "Sushi";
			return FavoriteFood;
		}
	}
}