﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SimpleCSharpConsoleApp
{
    public class Car
    {
        public string CarName;
        public string FavoriteFood;
    }
}